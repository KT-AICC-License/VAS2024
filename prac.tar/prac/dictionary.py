item = {'KT': 1, 'AI': 2, 'Azure': 3}

for key,value in item.items():
    print(f"{key}: {value}")
    #print(item.keys(),item.values())
# Print keys
#print("Keys:", list(my_dict.keys()))

# Print values
#print("Values:", list(my_dict.values()))

