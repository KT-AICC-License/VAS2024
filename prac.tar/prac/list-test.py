thelist  = ["KT","AI","Azure"]
for i in thelist:
    print(i)
